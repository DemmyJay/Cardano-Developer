{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE TemplateHaskell #-}

module Main where

import Control.Concurrent
import Control.Lens
import Control.Lens.TH
import Control.Monad.Reader
import Control.Monad.State
import System.Console.ANSI
import System.IO
import System.Random

setNoBuffering :: IO ()
setNoBuffering = do
  hSetBuffering stdin NoBuffering
  hSetBuffering stdout NoBuffering

type Row        = Int
type Col        = Int
type Size       = (Int, Int)
data Config     = Config { _size :: Size }
makeLenses ''Config

type Point      = (Int, Int)
newtype Snake   = Snake { _getSnake :: [Point] } deriving Show
makeLenses ''Snake

newtype Food    = Food { _getFood :: Point } deriving Show
makeLenses ''Food

data Direction  = U | D | L | R deriving Show
type Score      = Int
data Status     = On | Over deriving Show

data Game       = Game
  { _snake     :: Snake
  , _food      :: Food
  , _direction :: Direction
  , _score     :: Score
  , _status    :: Status
  } deriving Show

makeLenses ''Game

mkConfig :: IO Config
mkConfig = do
  Just (mrow, mcol) <- getTerminalSize
  return $ Config { _size = (mrow, mcol) }

mkGame :: IO Game
mkGame = do
  Just (mrow, mcol) <- getTerminalSize
  frow <- randomRIO (2, mrow - 2)
  fcol <- randomRIO (2, mcol - 2)
  return $ Game
    { _snake     = Snake $ zip (replicate 3 10) [ 12, 13, 14 ]
    , _food      = Food (frow, fcol)
    , _direction = L
    , _score     = 0
    , _status    = On
    }

-- MonadIO            => IO is present "somewhere" in the mega monad stack
-- MonadState Game    => State is present "anywhere" in the mega monad stack
-- MonadReader Config => Reader is present "anywhere" in the mega monad stack

-- ExceptT Error (StateT Game IO) 
-- IO
-- Maybe
-- Reader Config
-- ReaderT Config (State Game) 
-- ReaderT Config (StateT Game IO) 
-- State Game
-- StateT Game (ReaderT Config IO) 
-- StateT Game (ReaderT Config Maybe)
-- StateT Game Maybe

liftS :: State s a -> ReaderT r (StateT s IO) a
liftS sg = lift $ StateT $ \g -> let (a, g') = runState sg g in return (a, g')

changeScore :: (MonadIO m, MonadState Game m) => m ()
changeScore = do
  score %= (+ 1)
  liftIO $ setCursorPosition 0 7
  currentScore <- use score
  liftIO $ print currentScore

renderPoint :: Char -> (Row, Col) -> IO ()
renderPoint x (r, c) = setCursorPosition r c >> putChar x

renderGame :: (MonadIO m, MonadReader Config m, MonadState Game m) => m ()
renderGame = do
  config <- ask
  game   <- get
  let (mrow, mcol)      = _size config
      Food (frow, fcol) = game ^. food
      s                 = game ^. snake . getSnake
  if frow < 2 || fcol < 2 || frow > mrow - 2 || fcol > mcol - 2
  then error "Food is out of boundary!"
  else liftIO $ do
    clearScreen
    forM_ (zip (repeat 1) [0 .. mcol]) (renderPoint '-')
    forM_ (zip (repeat (mrow - 1)) [0 .. mcol]) (renderPoint '-')
    forM_ (zip [1 .. mrow] (repeat 0)) (renderPoint '|')
    forM_ (zip [1 .. mrow] (repeat mcol)) (renderPoint '|')
    renderPoint '&' (frow, fcol)
    renderPoint 'o' $ head s
    forM_ (tail s) (renderPoint 'x')
    setCursorPosition 0 (mcol - 3)
    print $ _score game
    return ()

play :: ReaderT Config (StateT Game IO) ()
play = do
  renderGame
  liftIO $ threadDelay (10 ^ 6)
  liftIO $ threadDelay (10 ^ 6)
  liftIO $ threadDelay (10 ^ 6)
  changeScore

main :: IO ()
main = do
  setNoBuffering
  config  <- mkConfig
  game    <- mkGame
  runStateT (runReaderT play config) game
  _ <- getChar
  showCursor
  return ()
