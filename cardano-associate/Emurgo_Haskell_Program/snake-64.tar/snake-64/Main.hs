{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE TemplateHaskell #-}

module Main where

import Control.Concurrent
import Control.Lens
import Control.Lens.TH
import Control.Monad.Reader
import Control.Monad.State
import System.Console.ANSI
import System.IO
import System.Random

setNoBuffering :: IO ()
setNoBuffering = do
  hSetBuffering stdin NoBuffering
  hSetBuffering stdout NoBuffering

type Row        = Int
type Col        = Int
type Size       = (Int, Int)
data Config     = Config { _size :: Size }
makeLenses ''Config

type Point      = (Int, Int)
newtype Snake   = Snake { _getSnake :: [Point] } deriving Show
makeLenses ''Snake

newtype Food    = Food { _getFood :: Point } deriving Show
makeLenses ''Food

data Direction  = U | D | L | R deriving (Eq, Show)
type Score      = Int
data Status     = On | Over deriving Show

data Game       = Game
  { _snake     :: Snake
  , _food      :: Food
  , _direction :: Direction
  , _score     :: Score
  , _status    :: Status
  } deriving Show
makeLenses ''Game

mkConfig :: IO Config
mkConfig = do
  Just (mrow, mcol) <- getTerminalSize
  return $ Config { _size = (mrow, mcol) }

mkFood :: IO Food
mkFood = do
  Just (mrow, mcol) <- getTerminalSize
  frow <- randomRIO (2, mrow - 2)
  fcol <- randomRIO (2, mcol - 2)
  return $ Food (frow, fcol)

mkGame :: IO Game
mkGame = do
  f <- mkFood
  return $ Game
    { _snake     = Snake $ zip (replicate 3 10) [ 12, 13, 14 ]
    , _food      = f
    , _direction = L
    , _score     = 0
    , _status    = On
    }

isValid :: Direction -> Direction -> Bool
isValid D U = False
isValid L R = False
isValid R L = False
isValid U D = False
isValid _ _ = True

turnSnake :: MonadState Game m => Direction -> m ()
turnSnake d1 = do
  d0 <- fmap _direction get
  if isValid d1 d0
  then direction .= d1
  else return ()

moveHead :: Direction -> Point -> Point
moveHead D (r, c) = (r + 1, c)
moveHead L (r, c) = (r, c - 1)
moveHead R (r, c) = (r, c + 1)
moveHead U (r, c) = (r - 1, c)

moveSnake :: (MonadIO m, MonadState Game m) => m ()
moveSnake = do 
  game <- get
  let oldSnake      = game ^. snake . getSnake
      oldDirection  = game ^. direction
      oldFood       = game ^. food . getFood
      newHead       = moveHead oldDirection (head oldSnake)
  newFood <- liftIO mkFood
  if oldFood == newHead then do
    snake .= Snake (newHead : oldSnake)
    food  .= newFood 
    score %= (+ 1)
  else do
    snake .= Snake (newHead : init oldSnake)

renderGame :: (MonadIO m, MonadReader Config m, MonadState Game m) => m ()
renderGame = do
  config <- ask
  game   <- get
  let (mrow, mcol)      = _size config
      Food (frow, fcol) = game ^. food
      s                 = game ^. snake . getSnake
  if frow < 2 || fcol < 2 || frow > mrow - 2 || fcol > mcol - 2
  then error "Food is out of boundary!"
  else liftIO $ do
    let renderPoint x (r, c) = setCursorPosition r c >> putChar x
    clearScreen
    forM_ (zip (repeat 1) [0 .. mcol]) (renderPoint '-')
    forM_ (zip (repeat (mrow - 1)) [0 .. mcol]) (renderPoint '-')
    forM_ (zip [1 .. mrow] (repeat 0)) (renderPoint '|')
    forM_ (zip [1 .. mrow] (repeat mcol)) (renderPoint '|')
    renderPoint '&' (frow, fcol)
    renderPoint 'o' $ head s
    forM_ (tail s) (renderPoint 'x')
    setCursorPosition 0 (mcol - 3)
    print $ _score game
    return ()

play :: (MonadIO m, MonadReader Config m, MonadState Game m) => m ()
play = forever $ do
  renderGame
  isInputAvailable <- liftIO (hWaitForInput stdin 200)
  if isInputAvailable
  then do
    c <- liftIO getChar
    case c of
      'h' -> turnSnake L >> moveSnake
      'j' -> turnSnake D >> moveSnake
      'k' -> turnSnake U >> moveSnake
      'l' -> turnSnake R >> moveSnake
  else moveSnake

main :: IO ()
main = do
  setNoBuffering
  config  <- mkConfig
  game    <- mkGame
  runStateT (runReaderT play config) game
  _ <- getChar
  showCursor
  return ()
